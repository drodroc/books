﻿@echo off
cd /d "%~dp0"
start "" "%~dp0月度算账.exe"
